import logo from './logo.svg';
import './App.css';
import WeatherReport from './component/WeatherReport';


function App() {
  return (
    <div className="App">
      <WeatherReport/>
    </div>
  );
}

export default App;
